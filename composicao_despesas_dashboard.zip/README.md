# Dashboard - Composição de Despesas

Dashboard interativo criado com Streamlit + Plotly para visualização da evolução mensal das contas contábeis.

## Como rodar localmente
```bash
streamlit run dashboard.py
```
